#include "stm32f10x.h"
#include "Myhead.h"

uint32_t SystemCont;
uint32_t Addr = 0XFFFFFFFF;//Ĭ��

//�̶���ʽ:��ͷ,�豸��ַ,����ʶ,������  9bit
void Head_length(uint32_t Address, uint8_t Identification,uint16_t Length){
	
	Serial_TxPacket[0]=0xEF;
	Serial_TxPacket[1]=0x01;
	
	Serial_TxPacket[2]=Address>>24;
	Serial_TxPacket[3]=Address>>16;
	Serial_TxPacket[4]=Address>>8;
	Serial_TxPacket[5]=Address;
	
	Serial_TxPacket[6]=Identification;
	
	Serial_TxPacket[7]=Length>>8;
	Serial_TxPacket[8]=Length;
}

void Sendtemp(uint16_t temp,uint8_t Addr_h,uint8_t Addr_l){

	Serial_TxPacket[Addr_h]=temp>>8; 
	Serial_TxPacket[Addr_l]=temp; 
}

void SendTagNo(uint16_t TagNo,uint8_t Addr_h,uint8_t Addr_l){

	Serial_TxPacket[Addr_h]=TagNo>>8; 
	Serial_TxPacket[Addr_l]=TagNo; 
}

void Sendpage(uint16_t page,uint8_t Addr_h,uint8_t Addr_l){

	Serial_TxPacket[Addr_h]=page>>8; 
	Serial_TxPacket[Addr_l]=page; 
}

void Clear_TX_Data(uint16_t number){

	for(uint16_t i=0;i<number;i++){
	Serial_TxPacket[i]=0;
	}
}

void Clear_RX_Data(uint16_t number){

	for(uint16_t i=0;i<number;i++){
	Serial_RxPacket[i]=0;
	}
}
//�̵���˸
void color_G_flickering(uint8_t times){
	
	Clear_TX_Data(16);
	
	Head_length(Addr,0x01,0x07);//7bit

	Serial_TxPacket[9]=0x3C;  
	Serial_TxPacket[10]=0x02;
	Serial_TxPacket[11]=0x02;
	Serial_TxPacket[12]=0x00;
	Serial_TxPacket[13]=times;
	
	uint16_t temp=0x01 + 0x07 + 0x3C + 0x02 + 0x02 + 0x00 + times;
	Sendtemp(temp, 14,15);
	
	UART1_DMA_Tx(16);
}

//�����˸
void color_R_flickering(uint8_t times){
	
	Clear_TX_Data(16);
	
	Head_length(Addr,0x01,0x07);//7bit

	Serial_TxPacket[9]=0x3C;  
	Serial_TxPacket[10]=0x02;
	Serial_TxPacket[11]=0x04;
	Serial_TxPacket[12]=0x00;
	Serial_TxPacket[13]=times;
	
	uint16_t temp=0x01 + 0x07 + 0x3C + 0x02 + 0x04 + 0x00 + times;
	Sendtemp(temp, 14,15);
	
	UART1_DMA_Tx(16);
}

//��ɫ������
void color_B_breathinglamp(void){
	
	Clear_TX_Data(16);
	
	Head_length(Addr,0x01,0x07);//7bit

	Serial_TxPacket[9]=0x3C;  
	Serial_TxPacket[10]=0x01;
	Serial_TxPacket[11]=0x01;
	Serial_TxPacket[12]=0x00;
	Serial_TxPacket[13]=0x00;
	
	uint16_t temp=0x01 + 0x07 + 0x3C + 0x01 + 0x01 + 0x00 + 0x00;
	Sendtemp(temp, 14,15);
	
	UART1_DMA_Tx(16);
}

//�̵Ƴ���
void color_G(void){
	
	Clear_TX_Data(16);
	
	Head_length(Addr,0x01,0x07);//7bit

	Serial_TxPacket[9]=0x3C;  
	Serial_TxPacket[10]=0x03;
	Serial_TxPacket[11]=0x02;
	Serial_TxPacket[12]=0x00;
	Serial_TxPacket[13]=0x01;
	
	uint16_t temp=0x01 + 0x07 + 0x3C + 0x03 + 0x02 + 0x00 + 0x01;
	Sendtemp(temp, 14,15);
	
	UART1_DMA_Tx(16);
}


uint8_t PS_GetImage(void){
	
	uint8_t ensure=0xff;
	Clear_TX_Data(12);
	
	Head_length(Addr,0x01,0x03);
	Serial_TxPacket[9]=0x01; 
	Sendtemp(0x05, 10,11);
	
	UART1_DMA_Tx(12);

	Delay_ms(200);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	ensure=1;
	Clear_RX_Data(12);
	} 
	else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x01){
	ensure=0;
	color_R_flickering(0x02);
	Clear_RX_Data(12);
	} 
	
	return ensure;
}

uint8_t PS_GenChar(uint8_t BUFFER_ID){

	uint8_t ensure=0xff;
	Clear_TX_Data(13);
	
	Head_length(Addr,0x01,0x04);
	Serial_TxPacket[9]=0x02;
	Serial_TxPacket[10]=BUFFER_ID;
	
	uint16_t temp=0x01 + 0x04 + 0x02 + BUFFER_ID;
	Sendtemp(temp, 11,12);
	
	UART1_DMA_Tx(13);
	
	Delay_ms(200);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	ensure=1;
	color_G_flickering(0x02);
	Clear_RX_Data(12);
	} 

	return ensure;
}

uint8_t PS_RegModel (void){

	uint8_t ensure=0xff;
	Clear_TX_Data(12);
	
	Head_length(Addr,0x01,0x03);
	Serial_TxPacket[9]=0x05;
	
	Sendtemp(0x0009, 10,11);
	
	UART1_DMA_Tx(12);
	
	Delay_ms(200);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	ensure=1;
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x0A){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x01){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}

	return ensure;
}

uint8_t PS_StoreChar  (void){

	uint8_t ensure=0xff;
	Clear_TX_Data(15);
	
	Head_length(Addr,0x01,0x06);
	Serial_TxPacket[9]=0x06;
	Serial_TxPacket[10]=0x01;
	
	uint16_t TagNo=store_Data[5]+1;
	 SendTagNo(TagNo,11,12);
	
	uint16_t temp=0x01 + 0x06 +0x06 + 0x01 + TagNo;
	Sendtemp(temp, 13,14);
	
	
	UART1_DMA_Tx(15);
	
	Delay_ms(500);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	ensure=1;
	store_Data[5]=TagNo;
	Store_Save();
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x0B){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x18){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}
	else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x01){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}

	return ensure;
}


uint16_t Process=0;//���̱���
uint8_t ensure=0x0ff;
uint8_t Enter_fingerprint(void){
	uint8_t flag=0;
	switch(Process){
		case 0://��ȡͼ��,��������--1
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=1;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;
		case 1:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=2;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;

		case 2:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=3;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;

		case 3:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=4;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;
		
		case 4:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=5;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;
		
		case 5:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=6;
			OLED_ShowNum(68,40,7-Process,1,16,1);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;

		case 6:
		if(PS_GetImage()==1){
			if(PS_GenChar(Process+1)==1){
			Process=7;
			OLED_Clear();//�ϲ�������
			OLED_Refresh();
			oled_showsentence(10);
			OLED_Refresh();
			Delay_ms(500);
			}
		}
			break;
		
		case 7:
		ensure=PS_RegModel();
		if(ensure==1){
			ensure=0xff;//��ԭensure
			Process=8;
			OLED_Clear();
			OLED_Refresh();
			
			oled_showsentence(11);
			OLED_Refresh();
			Delay_ms(500);
		}else if(ensure==0){
			ensure=0xff;
			Process=0;
			OLED_Clear();
			OLED_Refresh();

			oled_showsentence(12);
			OLED_Refresh();
			Delay_ms(2000);	

			OLED_Clear();
			OLED_Refresh();
			oled_showsentence(8);
			oled_showsentence(9);
			
		}
			break;
		
		case 8:
			ensure=PS_StoreChar();
			if(ensure==1){
			ensure=0xff;//��ԭensure
			Process=0;
			flag=1;
			OLED_Clear();
			OLED_Refresh();
				
			oled_showsentence(13);
			OLED_Refresh();
			Delay_ms(1000);
							
			
			}else if(ensure==0){
			ensure=0xff;//��ԭensure
			Process=0;
			OLED_Clear();
			OLED_Refresh();

			oled_showsentence(12);
			OLED_Refresh();
			Delay_ms(1000);	

			OLED_Clear();
			OLED_Refresh();
			oled_showsentence(8);
			oled_showsentence(9);			
				
			}
			break;
	}

	return flag;
}

uint8_t PS_Empty (void){

	uint8_t ensure=0xff;
	Clear_TX_Data(12);
	
	Head_length(Addr,0x01,0x03);
	Serial_TxPacket[9]=0x0D;
	
	
	Sendtemp(0x0011, 10,11);
	
	UART1_DMA_Tx(12);
	
	Delay_ms(200);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	store_Data[5]=0;
	Store_Save();
	ensure=1;
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x11){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x01){
	ensure=0;
	color_R_flickering(0x03);
	Clear_RX_Data(12);
	}

	return ensure;
}


uint8_t PS_Search(void){

	uint8_t ensure=0xff;
	Clear_TX_Data(17);
	
	Head_length(Addr,0x01,0x08);
	Serial_TxPacket[9]=0x04;
	Serial_TxPacket[10]=0x01;//������
	
	Sendpage(0x0000,11,12);
	Sendpage(0x0050,13,14);
		
	uint16_t temp=0x01+0x08+0x04+0x01+0x0050;
	Sendtemp(temp, 15,16);
	
	UART1_DMA_Tx(17);
	
	Delay_ms(200);//ע�ⷢ�ͺ���ʱ���������ݻ�δ���ؾͽ����ж�
	if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x00){
	ensure=1;
	Clear_RX_Data(16);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x09){
	ensure=2;
	color_R_flickering(0x03);
	Clear_RX_Data(16);
	}else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x01){
	ensure=3;
	color_R_flickering(0x03);
	Clear_RX_Data(16);
	}
	else if(Serial_RxPacket[0]==0xEF && Serial_RxPacket[1]==0x01 && Serial_RxPacket[9]==0x17){
	ensure=4;
	color_R_flickering(0x03);
	Clear_RX_Data(16);
	}

	return ensure;

}

uint8_t Process1=0;
uint8_t Press_FR(void){
		switch(Process1){
		case 0://��ȡͼ��,��������--1
		if(PS_GetImage()==1){
			if(PS_GenChar(Process1+1)==1)
			Process1=1;
			
		}
			break;
		case 1:
		if(PS_Search()==1){
		Process1=0;
		oled_showsentence(1);
		OLED_Refresh();
		return 1;
			
		}else{
		Process1=0;
		}
		break;		
	}
	return 0;
}

uint8_t cont1=0;
void check(void){

	if(mode==0){
		if(Press_FR()==1){
			cont1=SystemCont;
			Servo_SetAngle(store_Data[6]);
		}
		if(cont1!=0 && (SystemCont-cont1>=3)){
			Servo_SetAngle(0);
			oled_showsentence(0);
			OLED_Refresh();
			cont1=0;
		}
	  }

}








