#ifndef __FINGERPRINT_H
#define __FINGERPRINT_H

#include "stm32f10x.h"

extern uint32_t SystemCont;
void color_G(void);
void color_B_breathinglamp(void);
uint8_t Enter_fingerprint(void);
uint8_t PS_Empty (void);
uint8_t PS_GetImage(void);
void color_R_flickering(uint8_t times);
void Clear_RX_Data(uint16_t number);
uint8_t PS_Search(void);
uint8_t Press_FR(void);
void check(void);
#endif
