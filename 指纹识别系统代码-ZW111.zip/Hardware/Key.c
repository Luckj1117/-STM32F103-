#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Myhead.h"

uint32_t mode = 0;//系统进程变量
uint8_t size=16;//菜单界面字符大小
int16_t Password[4];
uint8_t number=0;
uint32_t cont=0;//长按确定更改密码计数器
int8_t number1=0;
uint32_t Operating_cont=0;//非阻塞式延时计数变量

/**
  * 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 |GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PB1和PB11引脚初始化为上拉输入
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Operating_system(void){
	
	if(mode==0){
		number=0;
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);	//等待按键松手
		mode=1;
		
		OLED_Clear();
		oled_showsentence(3);//显示输入密码
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
			
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);	//等待按键松手
		mode=1;
		OLED_Clear();
		oled_showsentence(3);//显示输入密码
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
			
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);	//等待按键松手
		mode=1;
		OLED_Clear();
		oled_showsentence(3);//显示输入密码
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
			
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
	}
}
	
		else if(mode==1){
		
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);	//等待按键松手
		Password[number]++;
		if(Password[number]>9) Password[number]=0;
		
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
			
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);	//等待按键松手
		number++;
		if(number>3) number=0;
		
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
			
		if(number==0){
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);		
		}else if(number==1){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,'^',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
		}else if(number==2){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,'^',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);				
		}else if(number==3){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,'^',16,1);				
		}
		
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);	//等待按键松手
		Password[number]--;
		if(Password[number]<0) Password[number]=9;
			
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
	}
		
	if(Password[0]==store_Data[1]&&
	   Password[1]==store_Data[2]&&
	   Password[2]==store_Data[3]&&
	   Password[3]==store_Data[4]){
	   OLED_Clear();
	   mode=2;
	}
	
	
}
		
		else if(mode==2){
		
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);	//等待按键松手
		Password[number]++;
		if(Password[number]>9) Password[number]=0;
		
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);	//等待按键松手
		number++;
		if(number>3) number=0;
		
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);	//等待按键松手
		Password[number]--;
		if(Password[number]<0) Password[number]=9;
			
		OLED_ShowNum(17*2,34,Password[0],1,16,1);
		OLED_ShowNum(17*3,34,Password[1],1,16,1);
		OLED_ShowNum(17*4,34,Password[2],1,16,1);
		OLED_ShowNum(17*5,34,Password[3],1,16,1);
	}
		
	if(Password[0]==store_Data[1]&&
	   Password[1]==store_Data[2]&&
	   Password[2]==store_Data[3]&&
	   Password[3]==store_Data[4]){
	   OLED_Clear();
	   OLED_ShowChar(0,0,'>',size,1);
	   oled_showsentence(4);
	   oled_showsentence(5);
	   oled_showsentence(14);
	   OLED_ShowString(16,48,"Set Angle",16,1);
	   mode=3;
	}
}
	
		else if(mode==3){
		
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);	//等待按键松手
		number1--;
		if(number1<0) number1=0;
			
	    OLED_Clear();
	    OLED_ShowChar(0,number1*size,'>',size,1);
	    oled_showsentence(4);
	    oled_showsentence(5);
		oled_showsentence(14);
		OLED_ShowString(16,48,"Set Angle",16,1);
			
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);	//等待按键松手
		if(number1==0){
		OLED_Clear();
		oled_showsentence(7);//输入新密码
		number=1;//注意从地址为一的flash区域开始存4位数密码

		OLED_ShowNum(17*2,34,store_Data[1],1,16,1);
		OLED_ShowNum(17*3,34,store_Data[2],1,16,1);
		OLED_ShowNum(17*4,34,store_Data[3],1,16,1);
		OLED_ShowNum(17*5,34,store_Data[4],1,16,1);	
			
		if(number==1){
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);		
		}else if(number==2){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,'^',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
		}else if(number==3){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,'^',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);				
		}else if(number==4){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,'^',16,1);				
		}			
		
		}
		else if(number1==1){
		OLED_Clear();
		oled_showsentence(8);
		oled_showsentence(9);
		}
		else if(number1==2){
		OLED_Clear();
		oled_showsentence(15);
		}
		else if(number1==3){
		OLED_Clear();
		OLED_ShowString(0,24,"Angle:",16,1);
		OLED_ShowNum(16*3,24,store_Data[6],3,16,1);
		}
		mode=4;
		
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);	//等待按键松手
		number1++;
		if(number1>3) number1=3;
			
	    OLED_Clear();
	    OLED_ShowChar(0,number1*size,'>',size,1);
	    oled_showsentence(4);
	    oled_showsentence(5);
		oled_showsentence(14);
		OLED_ShowString(16,48,"Set Angle",16,1);
	}
		
	
}

		else if(mode==4){
	
	
		
	if(number1==0){
		
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);	//等待按键松手
		cont=0;

		store_Data[number]++;
		if(store_Data[number]>9) store_Data[number]=0;
		
		OLED_ShowNum(17*2,34,store_Data[1],1,16,1);
		OLED_ShowNum(17*3,34,store_Data[2],1,16,1);
		OLED_ShowNum(17*4,34,store_Data[3],1,16,1);
		OLED_ShowNum(17*5,34,store_Data[4],1,16,1);			
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		cont++;
		if(cont>=72*10000*3) {
		Store_Save();
		OLED_Clear();
		oled_showsentence(6);
		mode=5;
		Operating_cont=SystemCont;
		break;
		}
	};	//等待按键松手
	cont=0;
	number++;
	if(number>4) number=1;
	
		if(number==1){
		OLED_ShowChar(17*2 ,50,'^',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);		
		}else if(number==2){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,'^',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);
		}else if(number==3){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,'^',16,1);
		OLED_ShowChar(17*5 ,50,' ',16,1);				
		}else if(number==4){
		OLED_ShowChar(17*2 ,50,' ',16,1);
		OLED_ShowChar(17*3 ,50,' ',16,1);
		OLED_ShowChar(17*4 ,50,' ',16,1);
		OLED_ShowChar(17*5 ,50,'^',16,1);				
		}
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);	//等待按键松手
		cont=0;
			
		store_Data[number]--;
		if(store_Data[number]<0) store_Data[number]=9;
		
		OLED_ShowNum(17*2,34,store_Data[1],1,16,1);
		OLED_ShowNum(17*3,34,store_Data[2],1,16,1);
		OLED_ShowNum(17*4,34,store_Data[3],1,16,1);
		OLED_ShowNum(17*5,34,store_Data[4],1,16,1);			
	}			
  }else if(number1==1){
	  if(Enter_fingerprint()==1) mode=5;
  }else if(number1==2){
	  
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		cont++;
		if(cont>=72*10000*3) {
			if(PS_Empty()==1){
			OLED_Clear();
			oled_showsentence(16);
			Operating_cont=SystemCont;
			mode=5;
	  }
		break;
		}
	};	//等待按键松手
}
	cont=0;		  
  }else if(number1==3){
	
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){//任意按键改变系统状态，并进入下一显示界面
		cont=0;
		while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0){
		cont++;
			if(cont>=72*10000*2){
			store_Data[6]++;
			if(store_Data[6]>180) store_Data[6]=180;
			OLED_ShowNum(16*3,24,store_Data[6],3,16,1);
			OLED_Refresh();
			Delay_ms(100);
			}
		
		}	//等待按键松手
		
		store_Data[6]++;
		if(store_Data[6]>180) store_Data[6]=180;
		OLED_ShowNum(16*3,24,store_Data[6],3,16,1);			
	}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		cont=0;
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0){
		cont++;
		if(cont>=72*10000*3) {
		Store_Save();
		OLED_Clear();
		oled_showsentence(6);
		mode=5;
		Operating_cont=SystemCont;
		break;
		}
	};	//等待按键松手
}
	
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		cont=0;
		while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0){
		cont++;
			if(cont>=72*10000*2){
			store_Data[6]--;
			if(store_Data[6]<30) store_Data[6]=30;
			OLED_ShowNum(16*3,24,store_Data[6],3,16,1);
			OLED_Refresh();
			Delay_ms(100);
			}				
		}	//等待按键松手
		
			
		store_Data[6]--;
		if(store_Data[6]<30) store_Data[6]=30;
		OLED_ShowNum(16*3,24,store_Data[6],3,16,1);
			
	}	  
	  
  }
	
}
		else if(mode==5){
    if(SystemCont-Operating_cont>=4){
	Password[0]=0;
	Password[1]=0;
	Password[2]=0;
	Password[3]=0;
	mode=0;
	OLED_Clear();
	oled_showsentence(0);
	}
		}
}

