#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
void Operating_system(void);
extern uint32_t mode;
#endif
