#ifndef __SERIAL_H
#define __SERIAL_H

#include "stm32f10x.h"

extern uint8_t Serial_RxPacket[256];
extern uint8_t Serial_TxPacket[256];
extern uint16_t package;
void SerialDMA_Init(void);

void UART1_DMA_Tx(uint32_t Number);

#endif
