#ifndef __MYFLASH_H
#define __MYFLASH_H

#include "stm32f10x.h"  
uint32_t Flash_ReadWord(uint32_t Address);
uint16_t Flash_ReadHalfWord(uint32_t Address);
uint8_t Flash_ReadByte(uint32_t Address);

void FlashsALLPAges(void);
void Flash_ErasePAge(uint32_t PageAddress);
void Flash_ProgramWord(uint32_t Address,uint32_t Data);
void Flash_ProgramHalfWord(uint32_t Address,uint16_t Data);

#endif
