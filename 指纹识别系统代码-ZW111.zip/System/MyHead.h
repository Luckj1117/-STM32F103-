#ifndef __MYHEAD_H
#define __MYHEAD_H

#include "stm32f10x.h"  
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Servo.h"
#include "Timer.h"
#include "Key.h"
#include "FINGERPRINT.h"
#include "MyFlash.h"
#include "Store.h"
#include "DMA.h"

#endif
