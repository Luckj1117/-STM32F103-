#ifndef __STORE_H
#define __STORE_H

void Store_Init(void);
void Store_Save(void);

extern int16_t store_Data[512];

#endif
