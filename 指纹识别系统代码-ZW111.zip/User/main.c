#include "stm32f10x.h"                  // Device header
#include "Myhead.h"

//typedef void (*pctr)(void);

//pctr number[2]={
//	&OLED_Init,&Servo_Init
//};

int main(void)
{
	OLED_Init();
//	number[0]();
	SerialDMA_Init();
	Key_Init();
	Servo_Init();
	Servo_SetAngle(0);
	
	oled_showsentence(0);
	Store_Init();
	
	Timer_Init();
	while (1)
	{
	OLED_Refresh();
	Operating_system();	
	check();		
   }
}



void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		SystemCont++;	
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

